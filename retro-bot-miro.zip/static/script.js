(function() {
  const categorySelect = document.getElementById('category');
  const nextBtn = document.getElementById('btn-next');
  const copyBtn = document.getElementById('btn-copy');
  const questionEl = document.getElementById('question');

  // Adjust base URL automatically if embedded (same origin)
  const BASE = '';

  async function loadCategories() {
    try {
      const res = await fetch(`${BASE}/categories`);
      const data = await res.json();
      const cats = data.categories || [];
      cats.forEach(c => {
        const opt = document.createElement('option');
        opt.value = c;
        opt.textContent = c;
        categorySelect.appendChild(opt);
      });
    } catch (e) {
      console.error('Erro ao carregar categorias', e);
    }
  }

  async function getRandom() {
    const cat = categorySelect.value;
    const url = cat ? `${BASE}/random?category=${encodeURIComponent(cat)}` : `${BASE}/random`;
    questionEl.textContent = '...';
    try {
      const res = await fetch(url);
      if (!res.ok) {
        throw new Error('Falha ao obter pergunta');
      }
      const item = await res.json();
      questionEl.textContent = item.text;
    } catch (e) {
      questionEl.textContent = 'Não foi possível obter uma pergunta agora 😅';
      console.error(e);
    }
  }

  async function copyToClipboard() {
    const text = questionEl.textContent.trim();
    if (!text) return;
    try {
      await navigator.clipboard.writeText(text);
      copyBtn.textContent = 'Copiado!';
      setTimeout(() => (copyBtn.textContent = 'Copiar'), 1200);
    } catch (e) {
      console.error('Falha ao copiar', e);
    }
  }

  // Resize observer to be friendly in iframe panels (like Miro)
  const ro = new ResizeObserver(() => {
    // PostMessage pattern could be added here for specific hosts if needed.
  });
  ro.observe(document.body);

  nextBtn.addEventListener('click', getRandom);
  copyBtn.addEventListener('click', copyToClipboard);

  loadCategories().then(getRandom);
})();