
import os
import json
import random
from typing import List, Optional
from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import HTMLResponse, JSONResponse, FileResponse
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
DATA_FILE = BASE_DIR / "questions.json"

app = FastAPI(title="Retro Questions Bot", version="1.0.0")

# Allow embedding in iframes (Miro). We purposely do not set X-Frame-Options to 'DENY'.
# CORS to allow Miro to fetch resources from your hosted domain.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

def load_questions():
    with open(DATA_FILE, "r", encoding="utf-8") as f:
        return json.load(f)

QUESTIONS = load_questions()

def list_categories() -> List[str]:
    return sorted({q["category"] for q in QUESTIONS})

@app.get("/health")
def health():
    return {"status": "ok"}

@app.get("/categories")
def categories():
    return {"categories": list_categories()}

@app.get("/questions")
def get_questions(category: Optional[str] = None, shuffle: bool = False, limit: Optional[int] = None):
    items = QUESTIONS
    if category:
        wanted = {c.strip() for c in category.split(",")}
        items = [q for q in items if q["category"] in wanted]
    if shuffle:
        random.shuffle(items)
    if limit is not None:
        try:
            limit = int(limit)
            items = items[:max(0, limit)]
        except ValueError:
            pass
    return {"count": len(items), "items": items}

@app.get("/random")
def random_question(category: Optional[str] = None):
    items = QUESTIONS
    if category:
        wanted = {c.strip() for c in category.split(",")}
        items = [q for q in items if q["category"] in wanted]
    if not items:
        raise HTTPException(status_code=404, detail="Nenhuma pergunta encontrada para o filtro informado.")
    return random.choice(items)

class NewQuestion(BaseModel):
    category: str
    text: str

def _save_questions(all_items):
    with open(DATA_FILE, "w", encoding="utf-8") as f:
        json.dump(all_items, f, ensure_ascii=False, indent=2)

@app.post("/add")
def add_question(payload: NewQuestion, request: Request):
    # Optional simple protection via ADMIN_TOKEN env var
    admin_token = os.environ.get("ADMIN_TOKEN")
    supplied = request.headers.get("X-Admin-Token")
    if admin_token and supplied != admin_token:
        raise HTTPException(status_code=401, detail="Unauthorized")
    new_id = max(q["id"] for q in QUESTIONS) + 1 if QUESTIONS else 1
    item = {"id": new_id, "category": payload.category, "text": payload.text}
    QUESTIONS.append(item)
    _save_questions(QUESTIONS)
    return {"ok": True, "item": item}

# Serve a minimal front-end
@app.get("/", response_class=HTMLResponse)
def index():
    with open(Path(__file__).resolve().parent.parent / "static" / "index.html", "r", encoding="utf-8") as f:
        return HTMLResponse(content=f.read(), status_code=200)

@app.get("/static/{path:path}")
def static_files(path: str):
    file_path = Path(__file__).resolve().parent.parent / "static" / path
    if file_path.exists() and file_path.is_file():
        return FileResponse(str(file_path))
    raise HTTPException(status_code=404, detail="Not found")
